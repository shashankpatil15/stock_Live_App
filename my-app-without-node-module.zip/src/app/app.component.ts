import {Component, Injectable } from '@angular/core'
import {$WebSocket, WebSocketSendMode} from 'angular2-websocket/angular2-websocket';
declare var $;
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

	
  title = 'Live Stock APP';
  now:number;
  live_data: any;
  full_ary = [];
  arr  = [];
   arrIndex = {};
  constructor(){
		var ws = new $WebSocket("ws://stocks.mnet.website");
		ws.onMessage(
			(msg: MessageEvent)=> {
				console.log("onMessage ", msg.data);
				this.live_data = JSON.parse(msg.data);
				// this.live_data.forEach((data) => console.log(data[0]));
				 this.live_data.forEach( data => {
						this.now = Date.now();
						this.addOrReplace({name:data[0],price:data[1],time:this.now ,colr:''})
				 })
				
			},
			{autoApply: false},
			
		);
  
	

  }

 
	 addOrReplace(object) {
		var index = this.arrIndex[object.name];
		if(index === undefined) {
			index = this.arr.length;
			this.arrIndex[object.name] = index;
		}
		//check values
	   // this.arr[index] = object; 
		
		const i = this.arr.findIndex(_item => _item.name ===  object.name);
		if (i > -1) {
			//object.colr = 'bg-success';
			// checking for  low or high
			var cld_name =(object.price>this.arr[i].price)?'':'bg-danger';
			object.colr	= cld_name;
			this.arr[i] = object; // (2)
		}
		else {
			console.log("push ")
			object.colr = 'bg-white';
			this.arr.push(object);
		}
		
		
	}
	
	change_visited(evt){
		// alert(evt);	
		$("#"+evt).attr('class', '').addClass('bg-success');
	}  
   
}
